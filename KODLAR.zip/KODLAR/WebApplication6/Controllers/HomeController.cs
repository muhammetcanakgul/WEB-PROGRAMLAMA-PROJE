﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;


namespace WebApplication6.Controllers
{
    public class HomeController : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Slider()
        {
            return View();
        }
        public ActionResult Ara()
        {
            ViewBag.Message = "Arama sonuç sayfası.";

            return View();
        }
        public ActionResult Iletisim()
        {
            return View();
        }
        public ActionResult Hakkimizda()
        {
            return View();
        }
        public ActionResult Aksiyon()
        {
            return View();
        }
        public ActionResult Macera()
        {
            return View();
        }
        public ActionResult Eniyiler()
        {
            return View();
        }
        public ActionResult Filmler()
        {
            return View();
        }
        public ActionResult Animasyon()
        {
            return View();
        }
        public ActionResult Belgesel()
        {
            return View();
        }
        public ActionResult BilimKurgu()
        {
            return View();
        }
        public ActionResult Dram()
        {
            return View();
        }
        public ActionResult Fantastik()
        {
            return View();
        }
        public ActionResult Komedi()
        {
            return View();
        }
        public ActionResult Korku()
        {
            return View();
        }
        public ActionResult Romantik()
        {
            return View();
        }
        public ActionResult Savaş()
        {
            return View();
        }

        public ActionResult Change(string lang)
        {
            Session["lang"] = lang;
            Thread.CurrentThread.CurrentCulture = new CultureInfo(Session["lang"].ToString());
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(Session["lang"].ToString());
            ViewBag.language = Session["lang"];
            return View("Index");
        }

    }
}
